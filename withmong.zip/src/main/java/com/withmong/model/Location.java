package com.withmong.model;

public class Location {
	
	private int no;
	private String city;
	private String local;
	
	public Location(){}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	@Override
	public String toString() {
		return "Location [no=" + no + ", city=" + city + ", local=" + local + "]";
	}
	
	
}
