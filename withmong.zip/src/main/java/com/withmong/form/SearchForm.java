package com.withmong.form;

public class SearchForm {

	private String type;
	private String search;
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	@Override
	public String toString() {
		return "SearchForm [type=" + type + ", search=" + search + "]";
	}
	
	
	
	
}
