package com.withmong.form;

public class CountForm {

	
	private int totalScore;
	private int rowCount;
	private double avglike;
	private int productNo;
	
	
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public int getRowCount() {
		return rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public double getAvglike() {
		return avglike;
	}
	public void setAvglike(double avglike) {
		this.avglike = avglike;
	}
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	
	
	
	
}
