package com.withmong.form;

public class BreadcrumbsForm {
	
	private String cateBName;
	private String cateSName;
	
	public String getCateBName() {
		return cateBName;
	}
	public void setCateBName(String cateBName) {
		this.cateBName = cateBName;
	}
	public String getCateSName() {
		return cateSName;
	}
	public void setCateSNames(String cateSName) {
		this.cateSName = cateSName;
	}
	

	
	
	
}
